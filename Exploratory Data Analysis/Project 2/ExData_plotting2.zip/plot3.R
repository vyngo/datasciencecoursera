# load packages
library(ggplot2)
# Read data
NEI <- readRDS("./Data/summarySCC_PM25.rds")
SCC <- readRDS("./Data/Source_Classification_Code.rds")

# create png pplot
createPNGPlot <- function(data, file_name){
  ggplot(data, aes(x=factor(year), y=emission, fill=type)) +
    geom_bar(stat = "identity") +
    facet_grid(. ~ type) +
    xlab("year") +
    ylab(expression("total PM emission (kilo ton)")) +
    labs(title = "Total PM emission in Baltimore group by type and year")
  ggsave(filename = file_name)
}

# build data: total PM2.5 emission from all sources for each of the years 1999, 2002, 2005, and 2008 in Baltimore City
filterData <- function(data){
  sub_data <- subset(data, fips=="24510")
  sub_data$Emissions <- (sub_data$Emissions)/1000 # use kilo ton
  mat <- with(sub_data, tapply(Emissions, list(as.factor(type), as.factor(year)), sum, na.rm=TRUE)) # calculate sum of emission group by type
  result <- as.data.frame(as.table(mat))
  names(result) <- c("type", "year", "emission")
  result
}

data <- filterData(NEI)

createPNGPlot(data, "plot3.png")