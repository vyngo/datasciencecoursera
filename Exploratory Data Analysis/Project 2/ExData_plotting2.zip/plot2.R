# Read data
NEI <- readRDS("./Data/summarySCC_PM25.rds")
SCC <- readRDS("./Data/Source_Classification_Code.rds")

# create png pplot
createPNGPlot <- function(data, file_name){
  png(file=file_name,height=480, width=480)
  barplot(data, main="Total PM2.5 Emission in Baltimore City", ylab = "PM2.5 Emission (kilo ton)", xlab="Year" , col="red")
  dev.off()
}

# build data: total PM2.5 emission from all sources for each of the years 1999, 2002, 2005, and 2008 in Baltimore City
processData <- function(data){
  sub_data <- subset(data, fips=="24510")
  sub_data$Emissions <- (sub_data$Emissions)/1000 # use kiloton
  with(sub_data, tapply(Emissions, as.factor(year), sum, na.rm=TRUE)) # calculate sum of emission group by year
}

data <- processData(NEI)

createPNGPlot(data, "plot2.png")