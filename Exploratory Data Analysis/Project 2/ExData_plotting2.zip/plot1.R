# Read data
NEI <- readRDS("./Data/summarySCC_PM25.rds")
SCC <- readRDS("./Data/Source_Classification_Code.rds")

# create png pplot
createPNGPlot <- function(data, file_name){
  png(file=file_name,height=480, width=480)
  barplot(data, main="Total PM2.5 Emission", ylab = "PM2.5 Emission (kilo ton)", xlab="Year" , col="red")
  dev.off()
}

# build data: total PM2.5 emission from all sources for each of the years 1999, 2002, 2005, and 2008
processData <- function(data){
  data$Emissions <- (data$Emissions) / 1000
  with(data, tapply(Emissions, as.factor(year), sum, na.rm=TRUE))
}

data <- processData(NEI)

createPNGPlot(data, "plot1.png")