# load packages
library(ggplot2)
library(dplyr)
# Read data
NEI <- readRDS("./Data/summarySCC_PM25.rds")
SCC <- readRDS("./Data/Source_Classification_Code.rds")

# build data: emissions from coal combustion-related sources
filterData <- function(data){
  data <- data %>% filter(fips=="24510" & type=="ON-ROAD")
  data <- data %>% group_by(year) %>% summarise(Emissions = sum(Emissions))
  data
}

# create png pplot
createPNGPlot <- function(data, file_name){
  ggplot(data, aes(x=factor(year), y=Emissions/1000)) +
    geom_bar(stat = "identity") +
    xlab("year") +
    ylab(expression("total PM emission (kilo ton)")) +
    labs(title = "Total PM emissions from motor vehicle sources in Baltimore City")
  ggsave(filename = file_name)
}

data <- filterData(NEI)
createPNGPlot(data, "plot5.png")