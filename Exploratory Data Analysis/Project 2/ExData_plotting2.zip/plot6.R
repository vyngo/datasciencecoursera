# load packages
library(ggplot2)
library(dplyr)
library(gridExtra)
# Read data
NEI <- readRDS("./Data/summarySCC_PM25.rds")
SCC <- readRDS("./Data/Source_Classification_Code.rds")

# build data: emissions from coal combustion-related sources
filterData <- function(data, flips_id, area_name){
  data <- data %>% filter(fips==flips_id & type=="ON-ROAD")
  data <- data %>% group_by(year) %>% summarise(Emissions = sum(Emissions))
  data$Area <- area_name
  data
}

# create png pplot
createPNGPlot <- function(data, file_name){
  p1 <- ggplot(data, aes(x=factor(year), y=Emissions/1000, fill=Area)) +
    geom_bar(stat="identity") + 
    ylab("total PM emissions (kilo tons)") + 
    xlab("year") +
    labs(expression("Total PM emissions from Motor vehicle in Baltimore and Los Angeles"))
  p2 <- ggplot(data, aes(x=year, y=Emissions/1000, col=Area)) +
    geom_line(size=1.0) + 
    ylab("total PM emissions (kilo tons)") + 
    xlab("year") +
    labs(expression("Total PM emissions from Motor vehicle in Baltimore and Los Angeles"))
  p <- grid.arrange(p1, p2, ncol= 1)
  ggsave(filename = file_name, plot(p))
}



data_bal <- filterData(NEI, "24510", "Baltimore City")
data_los <- filterData(NEI, "06037", "Los Angeles Count")
data <- rbind(data_bal, data_los)

createPNGPlot(data, "plot6.png")